<?php
// الاتصال بقاعدة البيانات
$db = mysqli_connect("localhost", "root", "12345678", "shipment");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// استقبال الـ ID الخاص بالعميل من النموذج
$phone_number = mysqli_real_escape_string($db, $_POST['Phone Number']);

// استعلام للحصول على الشحنات التي قام بها العميل
$query = "SELECT * FROM shipment WHERE customer_phone_number = '$phone_number'";

$result = mysqli_query($db, $query);

if (mysqli_num_rows($result) > 0) {
    // عرض الشحنات على الصفحة
    echo "<!DOCTYPE html>
            <html lang='en'>
            <head>
                <meta charset='UTF-8'>
                <meta http-equiv='X-UA-Compatible' content='IE=edge'>
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <title>Your Shipments</title>
            </head>
            <body>
                <h1>Shipments you have sent:</h1>
                <ul>";

    // عرض كل شحنة كعنصر في القائمة
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<li>Shipment ID: " . $row['id'] . " - Weight: " . $row['weight'] . " - Transmitter Warehouse: " . $row['transmitter_warehouse'] . "</li>";
    }

    echo "</ul>
            </body>
            </html>";
} else {
    echo "No shipments found for the provided Phone Number.";
}

// إغلاق الاتصال بقاعدة البيانات
mysqli_close($db);
