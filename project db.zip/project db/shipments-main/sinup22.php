<!doctype html>

<head>
	<title>Test</title>
	<meta charset='utf-8'>
</head>

<body>
	<?php
	$db = mysqli_connect("localhost", "root", "12345678", "customer");


	mysqli_select_db($db, "customer");
	$id = mt_rand(1000000, 9999999);
	$name = $_POST["Name"];
	$Address = $_POST["Location"];
	$phoneNumber = $_POST["Customer Phone Number"];
	$password = $_POST["Password"];
	//$retype_password=$_POST["pws2"];
	$email = $_POST["E-mail"];

	# $pattern = '/^[A-Za-z][_ $0-9A-Za-z]{8}$/';

	if ($password == $retype_password && preg_match($pattern, $phoneNumber)) {
		$in = "insert into customer (Name,Location,Customer Phone Number,Password,E-mail)
values('$name','$Address','$phoneNumber','$password','$retype_password','$email')";
		header("location:signin.html");
	} else
		print("The password is different or the login does not match the pattern please try again ");


	mysqli_query($db, $in);
	mysqli_close($db);


	?>
</body>