<!DOCTYPE html>
<html lang="en">

<head>
    <title> previos shipment </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>

    <?php
    include('shipmen_you_have_sent.php');
    $query = "SELECT * FROM shipment WHERE customer_phone_number = '$phone_number'";
    $result = mysqli_query($db, $query);
    while ($row = mysqli_fetch_array($result)) {
        echo "<center>
    <ul class='list-group'>
        <li class='list-group-item'>An item</li>
        <li class='list-group-item'>A second item</li>
        <li class='list-group-item'>A third item</li>
        <li class='list-group-item'>A fourth item</li>
        <li class='list-group-item'>And a fifth one</li>
    </ul>
        <h3>previous shipment</h3>
</center>";
    }
    ?>

</body>

</html>