<!DOCTYPE HTML>
<head>
<title> wae</title>
<meta charset='utf-8'>
</head>
<body>
<?php
//step 1:

$db=mysqli_connect("localhost","root","12345678","shopping") or die("connection Failed");

//step2:
mysqli_select_db($db,"shopping");

//step 3:

$login=$_POST["login"];
$Password=$_POST["password"];
$q="SELECT * from market where login ='$login' and password ='$Password'"; 

$result=mysqli_query($db,$q);
$count=mysqli_num_rows($result);
if($count>0)
{
	
	header("location:HomePagM1Top.html");
}
else
{
header("location:signin.html");

}
//mysqli_close($db);

?>
</body>