<?php
$db = mysqli_connect("localhost", "root", "12345678", "shipment");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// Generate a random 8-digit ID
$random_id = mt_rand(10000000, 99999999);

$weight = mysqli_real_escape_string($db, $_POST['weight']);
$transmitter_warehouse = mysqli_real_escape_string($db, $_POST['Transmitter_warehouse']);
$receiving_country = mysqli_real_escape_string($db, $_POST['Receiving_country']);
$submission_date = mysqli_real_escape_string($db, $_POST['date']);

$query = "INSERT INTO Shipment ('id', 'weight', Transmitter_warehouse, 'Receiving_country', 'date') 
            VALUES ('$random_id', '$weight', '$transmitter_warehouse', '$receiving_country', '$submission_date')";

if (mysqli_query($db, $query)) {
    mysqli_close($db);


    echo "<!DOCTYPE html>
            <html lang='en'>
            <head>
                <meta charset='UTF-8'>
                <meta http-equiv='X-UA-Compatible' content='IE=edge'>
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <title>Shipment ID</title>
            </head>
            <body>
                <h1>Your Shipment ID is: $random_id</h1>
            </body>
            </html>";
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($db);
}
