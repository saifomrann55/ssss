<?php
$db = mysqli_connect("localhost", "root", "12345678", "delivery");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $shipment_ID = $_POST['Shipment_ID'];

    $sql = "SELECT * FROM delivery WHERE id = '$shipment_ID'";
    $result = mysqli_query($db, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "ID: " . $row["id"] . "<br>";
            echo " Shipment Date:" . $row["delivery_date"] . "<br>";
            echo "Status: " . $row["status"] . "<br>";
        }
    } else {
        echo "There's no Shipment";
    }
}

// دالة لإضافة شحنة عشوائية
function generateRandomID()
{
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 8);
}

function addRandomDelivery($db)
{
    $id = generateRandomID();
    $delivery_date = date('Y-m-d', strtotime('+4 days'));
    $status = rand(0, 1) ? 'Shipped' : 'Waiting';

    $sql = "INSERT INTO delivery (id, Delivery_Date, status) VALUES ('$id', '$delivery_date', '$status')";
    mysqli_query($db, $sql);
}

// إضافة شحنة عشوائية
addRandomDelivery($db);

mysqli_close($db);
